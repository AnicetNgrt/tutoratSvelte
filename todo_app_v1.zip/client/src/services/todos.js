import axios from 'axios'
const baseUrl = 'http://localhost:3001/api/todos'

const getAll = () => {
  const request = axios.get(baseUrl);
  return request.then((response) => response.data);
};

const create = (todo) => {
  const request = axios.post(baseUrl, todo);
  return request.then((response) => response.data);
};

const update = (id, todo) => {
  const request = axios.put(`${baseUrl}/${id}`, todo);
  return request.then((response) => response.data);
};

const remove = (id) => {
  const request = axios.delete(`${baseUrl}/${id}`);
  return request.then((response) => response.data);
};

export default { 
  getAll, 
  create, 
  update,
	remove
}